from django import forms
from django.core.exceptions import ValidationError
from .models import Note, Subject, Tag
from core.models import User


class NoteUploadForm(forms.ModelForm):
    """Form for uploading new notes"""
    
    class Meta:
        model = Note
        fields = ['title', 'description', 'subject', 'text_content', 'file']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter note title'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Optional description of the note'
            }),
            'subject': forms.Select(attrs={
                'class': 'form-control'
            }),
            'text_content': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 10,
                'placeholder': 'Enter your notes here, or upload a file below'
            }),
            'file': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': '.pdf,.txt,.docx,.png,.jpg,.jpeg'
            })
        }
    
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['subject'].queryset = Subject.objects.filter(created_by=user)
        
        # Make text_content, file, and subject optional, but at least one content source is required
        self.fields['text_content'].required = False
        self.fields['file'].required = False
        self.fields['subject'].required = False
        self.fields['subject'].empty_label = "Select a subject (optional)"
    
    def clean(self):
        cleaned_data = super().clean()
        text_content = cleaned_data.get('text_content')
        file = cleaned_data.get('file')
        
        # At least one content source is required
        if not text_content and not file:
            raise ValidationError("Please provide either text content or upload a file.")
        
        # Validate file size (10MB limit)
        if file:
            if file.size > 10 * 1024 * 1024:  # 10MB
                raise ValidationError("File size cannot exceed 10MB.")
            
            # Validate file type
            allowed_extensions = ['pdf', 'txt', 'docx', 'png', 'jpg', 'jpeg']
            file_extension = file.name.split('.')[-1].lower()
            if file_extension not in allowed_extensions:
                raise ValidationError(f"File type '{file_extension}' is not supported. "
                                    f"Allowed types: {', '.join(allowed_extensions)}")
        
        return cleaned_data


class NoteEditForm(forms.ModelForm):
    """Form for editing existing notes"""
    
    class Meta:
        model = Note
        fields = ['title', 'description', 'subject', 'text_content']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3
            }),
            'subject': forms.Select(attrs={
                'class': 'form-control'
            }),
            'text_content': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 15
            })
        }
    
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['subject'].queryset = Subject.objects.filter(created_by=user)


class SubjectForm(forms.ModelForm):
    """Form for creating and editing subjects"""
    
    class Meta:
        model = Subject
        fields = ['name', 'description', 'color']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter subject name'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Optional description'
            }),
            'color': forms.TextInput(attrs={
                'class': 'form-control',
                'type': 'color',
                'value': '#007bff'
            })
        }


class BulkUploadForm(forms.Form):
    """Form for bulk uploading multiple files"""
    
    subject = forms.ModelChoiceField(
        queryset=Subject.objects.none(),
        widget=forms.Select(attrs={'class': 'form-control'}),
        help_text="Select the subject for all uploaded files"
    )
    
    # We'll handle multiple files in the view using request.FILES.getlist()
    # For now, keep it simple with a single file field
    file = forms.FileField(
        widget=forms.FileInput(attrs={
            'class': 'form-control',
            'accept': '.pdf,.txt,.docx'
        }),
        help_text="Select a file to upload"
    )
    
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['subject'].queryset = Subject.objects.filter(created_by=user)


class NoteSearchForm(forms.Form):
    """Form for searching notes"""
    
    search = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search notes...'
        })
    )
    
    subject = forms.ModelChoiceField(
        queryset=Subject.objects.none(),
        required=False,
        empty_label="All Subjects",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    status = forms.ChoiceField(
        choices=[('', 'All Status')] + Note.STATUS_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['subject'].queryset = Subject.objects.filter(created_by=user)


class TagForm(forms.ModelForm):
    """Form for creating tags"""
    
    class Meta:
        model = Tag
        fields = ['name']
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter tag name'
            })
        }
    
    def clean_name(self):
        name = self.cleaned_data['name'].lower().strip()
        
        # Check if tag already exists
        if Tag.objects.filter(name=name).exists():
            raise ValidationError("A tag with this name already exists.")
        
        return name