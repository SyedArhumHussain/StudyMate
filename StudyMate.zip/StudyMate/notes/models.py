from django.db import models
from django.core.validators import FileExtensionValidator
from core.models import User, Subject


def upload_to_user_folder(instance, filename):
    return f'notes/{instance.uploaded_by.id}/{filename}'


class Note(models.Model):
    CONTENT_TYPE_CHOICES = [
        ('text', 'Text Notes'),
        ('pdf', 'PDF Document'),
        ('image', 'Image'),
        ('mixed', 'Mixed Content'),
    ]
    
    STATUS_CHOICES = [
        ('uploaded', 'Uploaded'),
        ('processing', 'Processing'),
        ('processed', 'Processed'),
        ('failed', 'Processing Failed'),
    ]
    
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    content_type = models.CharField(max_length=10, choices=CONTENT_TYPE_CHOICES)
    text_content = models.TextField(blank=True, help_text="Direct text input or extracted from files")
    file = models.FileField(
        upload_to=upload_to_user_folder,
        blank=True,
        null=True,
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'txt', 'docx', 'png', 'jpg', 'jpeg'])]
    )
    
    # Metadata
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notes')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='notes', null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='uploaded')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # AI Processing flags
    is_summarized = models.BooleanField(default=False)
    has_flashcards = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['uploaded_by', 'subject']),
            models.Index(fields=['status']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return self.title
    
    @property
    def file_size(self):
        if self.file:
            return self.file.size
        return 0
    
    @property
    def file_extension(self):
        if self.file:
            return self.file.name.split('.')[-1].lower()
        return None


class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_tags')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['name']
    
    def __str__(self):
        return self.name


class NoteTag(models.Model):
    note = models.ForeignKey(Note, on_delete=models.CASCADE, related_name='note_tags')
    tag = models.ForeignKey(Tag, on_delete=models.CASCADE, related_name='note_tags')
    added_by = models.ForeignKey(User, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('note', 'tag')
    
    def __str__(self):
        return f"{self.note.title} - {self.tag.name}"
