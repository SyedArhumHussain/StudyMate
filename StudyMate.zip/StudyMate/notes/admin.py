from django.contrib import admin
from .models import Note, Tag, NoteTag


@admin.register(Note)
class NoteAdmin(admin.ModelAdmin):
    list_display = ('title', 'uploaded_by', 'subject', 'content_type', 'status', 'is_summarized', 'has_flashcards', 'created_at')
    list_filter = ('content_type', 'status', 'is_summarized', 'has_flashcards', 'created_at', 'subject')
    search_fields = ('title', 'description', 'uploaded_by__username', 'subject__name')
    ordering = ('-created_at',)
    readonly_fields = ('file_size', 'file_extension', 'created_at', 'updated_at')


@admin.register(Tag)
class TagAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_by', 'created_at')
    list_filter = ('created_at', 'created_by')
    search_fields = ('name', 'created_by__username')
    ordering = ('name',)


@admin.register(NoteTag)
class NoteTagAdmin(admin.ModelAdmin):
    list_display = ('note', 'tag', 'added_by', 'added_at')
    list_filter = ('added_at', 'tag', 'note__subject')
    search_fields = ('note__title', 'tag__name', 'added_by__username')
    ordering = ('-added_at',)
