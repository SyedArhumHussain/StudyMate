from rest_framework import serializers
from .models import Note, Subject, Tag, NoteTag
from ai_processing.models import Summary, Flashcard, StudySession
from core.models import User


class UserSerializer(serializers.ModelSerializer):
    """Serializer for User model"""
    
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'date_joined']
        read_only_fields = ['id', 'date_joined']


class SubjectSerializer(serializers.ModelSerializer):
    """Serializer for Subject model"""
    
    note_count = serializers.SerializerMethodField()
    processed_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Subject
        fields = ['id', 'name', 'description', 'color', 'created_at', 'note_count', 'processed_count']
        read_only_fields = ['id', 'created_at', 'note_count', 'processed_count']
    
    def get_note_count(self, obj):
        return obj.notes.count()
    
    def get_processed_count(self, obj):
        return obj.notes.filter(status='processed').count()


class TagSerializer(serializers.ModelSerializer):
    """Serializer for Tag model"""
    
    class Meta:
        model = Tag
        fields = ['id', 'name', 'created_at']
        read_only_fields = ['id', 'created_at']


class FlashcardSerializer(serializers.ModelSerializer):
    """Serializer for Flashcard model"""
    
    success_rate = serializers.ReadOnlyField()
    
    class Meta:
        model = Flashcard
        fields = [
            'id', 'question', 'answer', 'difficulty', 'category',
            'times_reviewed', 'times_correct', 'last_reviewed',
            'success_rate', 'ai_generated', 'confidence_score',
            'created_at', 'updated_at'
        ]
        read_only_fields = [
            'id', 'times_reviewed', 'times_correct', 'last_reviewed',
            'success_rate', 'ai_generated', 'confidence_score',
            'created_at', 'updated_at'
        ]


class SummarySerializer(serializers.ModelSerializer):
    """Serializer for Summary model"""
    
    word_count = serializers.ReadOnlyField()
    
    class Meta:
        model = Summary
        fields = [
            'id', 'summary_type', 'content', 'key_points',
            'processing_time', 'ai_model_used', 'confidence_score',
            'word_count', 'created_at', 'updated_at'
        ]
        read_only_fields = [
            'id', 'processing_time', 'ai_model_used', 'confidence_score',
            'word_count', 'created_at', 'updated_at'
        ]


class NoteListSerializer(serializers.ModelSerializer):
    """Serializer for Note list view (minimal fields)"""
    
    subject = SubjectSerializer(read_only=True)
    uploaded_by = serializers.StringRelatedField()
    file_size = serializers.ReadOnlyField()
    file_extension = serializers.ReadOnlyField()
    flashcard_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Note
        fields = [
            'id', 'title', 'description', 'content_type', 'status',
            'subject', 'uploaded_by', 'file_size', 'file_extension',
            'is_summarized', 'has_flashcards', 'flashcard_count',
            'created_at', 'updated_at'
        ]
    
    def get_flashcard_count(self, obj):
        return obj.flashcards.count()


class NoteDetailSerializer(serializers.ModelSerializer):
    """Serializer for Note detail view (all fields)"""
    
    subject = SubjectSerializer(read_only=True)
    uploaded_by = UserSerializer(read_only=True)
    summary = SummarySerializer(read_only=True)
    flashcards = FlashcardSerializer(many=True, read_only=True)
    file_size = serializers.ReadOnlyField()
    file_extension = serializers.ReadOnlyField()
    tags = serializers.SerializerMethodField()
    
    class Meta:
        model = Note
        fields = [
            'id', 'title', 'description', 'content_type', 'text_content',
            'file', 'status', 'subject', 'uploaded_by', 'summary',
            'flashcards', 'file_size', 'file_extension', 'tags',
            'is_summarized', 'has_flashcards', 'created_at', 'updated_at'
        ]
        read_only_fields = [
            'id', 'uploaded_by', 'status', 'file_size', 'file_extension',
            'is_summarized', 'has_flashcards', 'created_at', 'updated_at'
        ]
    
    def get_tags(self, obj):
        note_tags = obj.note_tags.all()
        return [{'id': nt.tag.id, 'name': nt.tag.name} for nt in note_tags]


class NoteCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating new notes"""
    
    subject_id = serializers.IntegerField(write_only=True)
    
    class Meta:
        model = Note
        fields = [
            'title', 'description', 'content_type', 'text_content',
            'file', 'subject_id'
        ]
    
    def validate_subject_id(self, value):
        user = self.context['request'].user
        try:
            Subject.objects.get(id=value, created_by=user)
        except Subject.DoesNotExist:
            raise serializers.ValidationError("Subject not found or not owned by user.")
        return value
    
    def validate(self, data):
        text_content = data.get('text_content')
        file = data.get('file')
        
        if not text_content and not file:
            raise serializers.ValidationError("Either text_content or file must be provided.")
        
        return data
    
    def create(self, validated_data):
        subject_id = validated_data.pop('subject_id')
        subject = Subject.objects.get(id=subject_id)
        validated_data['subject'] = subject
        validated_data['uploaded_by'] = self.context['request'].user
        
        return super().create(validated_data)


class StudySessionSerializer(serializers.ModelSerializer):
    """Serializer for StudySession model"""
    
    user = UserSerializer(read_only=True)
    score_percentage = serializers.ReadOnlyField()
    
    class Meta:
        model = StudySession
        fields = [
            'id', 'user', 'session_name', 'total_cards', 'correct_answers',
            'completed', 'score_percentage', 'started_at', 'completed_at',
            'duration_seconds'
        ]
        read_only_fields = [
            'id', 'user', 'score_percentage', 'started_at', 'completed_at'
        ]


class FlashcardStudySerializer(serializers.Serializer):
    """Serializer for flashcard study session data"""
    
    flashcard_id = serializers.IntegerField()
    answered_correctly = serializers.BooleanField()
    response_time_seconds = serializers.IntegerField(required=False)
    
    def validate_flashcard_id(self, value):
        user = self.context['request'].user
        try:
            Flashcard.objects.get(id=value, note__uploaded_by=user)
        except Flashcard.DoesNotExist:
            raise serializers.ValidationError("Flashcard not found or not accessible.")
        return value


class BulkUploadSerializer(serializers.Serializer):
    """Serializer for bulk file upload"""
    
    subject_id = serializers.IntegerField()
    files = serializers.ListField(
        child=serializers.FileField(),
        min_length=1,
        max_length=20
    )
    
    def validate_subject_id(self, value):
        user = self.context['request'].user
        try:
            Subject.objects.get(id=value, created_by=user)
        except Subject.DoesNotExist:
            raise serializers.ValidationError("Subject not found or not owned by user.")
        return value
    
    def validate_files(self, value):
        allowed_extensions = ['pdf', 'txt', 'docx', 'png', 'jpg', 'jpeg']
        max_file_size = 10 * 1024 * 1024  # 10MB
        
        for file in value:
            # Check file size
            if file.size > max_file_size:
                raise serializers.ValidationError(f"File '{file.name}' exceeds 10MB limit.")
            
            # Check file extension
            extension = file.name.split('.')[-1].lower()
            if extension not in allowed_extensions:
                raise serializers.ValidationError(
                    f"File '{file.name}' has unsupported extension. "
                    f"Allowed: {', '.join(allowed_extensions)}"
                )
        
        return value