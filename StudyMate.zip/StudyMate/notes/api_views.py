from rest_framework import generics, status, permissions, filters
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.pagination import PageNumberPagination
from django_filters.rest_framework import DjangoFilterBackend
from django.shortcuts import get_object_or_404
from django.db.models import Q, Count
from django.utils import timezone
from .models import Note, Subject, Tag
from .serializers import (
    NoteListSerializer, NoteDetailSerializer, NoteCreateSerializer,
    SubjectSerializer, TagSerializer, FlashcardStudySerializer,
    BulkUploadSerializer, StudySessionSerializer
)
from ai_processing.models import Flashcard, StudySession
from ai_processing.tasks import process_note_content_async, batch_process_notes
from dashboard.models import UserActivity
import logging

logger = logging.getLogger(__name__)


class StandardResultsSetPagination(PageNumberPagination):
    """Standard pagination class"""
    page_size = 20
    page_size_query_param = 'page_size'
    max_page_size = 100


class NoteListCreateAPIView(generics.ListCreateAPIView):
    """API endpoint for listing and creating notes"""
    
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['subject', 'status', 'content_type', 'is_summarized', 'has_flashcards']
    search_fields = ['title', 'description', 'text_content']
    ordering_fields = ['created_at', 'updated_at', 'title']
    ordering = ['-created_at']
    
    def get_queryset(self):
        return Note.objects.filter(uploaded_by=self.request.user).select_related(
            'subject', 'uploaded_by'
        ).prefetch_related('flashcards')
    
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return NoteCreateSerializer
        return NoteListSerializer
    
    def perform_create(self, serializer):
        note = serializer.save()
        
        # Log activity
        UserActivity.objects.create(
            user=self.request.user,
            activity_type='note_upload',
            description=f"Uploaded note via API: {note.title}",
            note=note,
            subject=note.subject
        )
        
        # Start async processing
        process_note_content_async.delay(note.id)


class NoteDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    """API endpoint for retrieving, updating, and deleting notes"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = NoteDetailSerializer
    
    def get_queryset(self):
        return Note.objects.filter(uploaded_by=self.request.user).select_related(
            'subject', 'uploaded_by', 'summary'
        ).prefetch_related('flashcards', 'note_tags__tag')
    
    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()
        
        # Log activity
        UserActivity.objects.create(
            user=request.user,
            activity_type='note_view',
            description=f"Viewed note via API: {instance.title}",
            note=instance,
            subject=instance.subject
        )
        
        return super().retrieve(request, *args, **kwargs)


class SubjectListCreateAPIView(generics.ListCreateAPIView):
    """API endpoint for listing and creating subjects"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = SubjectSerializer
    
    def get_queryset(self):
        return Subject.objects.filter(created_by=self.request.user).annotate(
            note_count=Count('notes'),
            processed_count=Count('notes', filter=Q(notes__status='processed'))
        )
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class SubjectDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    """API endpoint for retrieving, updating, and deleting subjects"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = SubjectSerializer
    
    def get_queryset(self):
        return Subject.objects.filter(created_by=self.request.user)


class FlashcardListAPIView(generics.ListAPIView):
    """API endpoint for listing flashcards"""
    
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = FlashcardStudySerializer
    pagination_class = StandardResultsSetPagination
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['difficulty', 'note', 'note__subject']
    ordering_fields = ['created_at', 'times_reviewed', 'last_reviewed']
    ordering = ['-created_at']
    
    def get_queryset(self):
        return Flashcard.objects.filter(note__uploaded_by=self.request.user).select_related('note')


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def reprocess_note_api(request, note_id):
    """API endpoint to trigger note reprocessing"""
    
    try:
        note = get_object_or_404(Note, id=note_id, uploaded_by=request.user)
        
        # Clear existing processing results
        if hasattr(note, 'summary'):
            note.summary.delete()
        note.flashcards.all().delete()
        
        # Reset flags
        note.is_summarized = False
        note.has_flashcards = False
        note.status = 'uploaded'
        note.save()
        
        # Start async processing
        task = process_note_content_async.delay(note.id)
        
        return Response({
            'success': True,
            'message': 'Note reprocessing started',
            'task_id': task.id,
            'note_id': note.id
        })
        
    except Exception as e:
        logger.error(f"Reprocessing failed for note {note_id}: {str(e)}")
        return Response({
            'success': False,
            'error': str(e)
        }, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def note_processing_status_api(request, note_id):
    """API endpoint to get note processing status"""
    
    note = get_object_or_404(Note, id=note_id, uploaded_by=request.user)
    
    return Response({
        'note_id': note.id,
        'status': note.status,
        'is_summarized': note.is_summarized,
        'has_flashcards': note.has_flashcards,
        'flashcard_count': note.flashcards.count(),
        'summary_available': hasattr(note, 'summary'),
        'processing_logs': [
            {
                'process_type': log.get_process_type_display(),
                'status': log.get_status_display(),
                'started_at': log.started_at,
                'completed_at': log.completed_at,
                'error_message': log.error_message
            }
            for log in note.processing_logs.all()[:5]
        ]
    })


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def bulk_upload_api(request):
    """API endpoint for bulk file upload"""
    
    serializer = BulkUploadSerializer(data=request.data, context={'request': request})
    if serializer.is_valid():
        subject_id = serializer.validated_data['subject_id']
        files = serializer.validated_data['files']
        
        subject = get_object_or_404(Subject, id=subject_id, created_by=request.user)
        
        uploaded_notes = []
        for file in files:
            # Determine content type
            file_ext = file.name.split('.')[-1].lower()
            if file_ext == 'pdf':
                content_type = 'pdf'
            elif file_ext in ['png', 'jpg', 'jpeg']:
                content_type = 'image'
            else:
                content_type = 'text'
            
            # Create note
            note = Note.objects.create(
                title=file.name.split('.')[0],  # Use filename as title
                uploaded_by=request.user,
                subject=subject,
                file=file,
                content_type=content_type
            )
            uploaded_notes.append(note.id)
        
        # Start batch processing
        batch_process_notes.delay(uploaded_notes)
        
        return Response({
            'success': True,
            'message': f'{len(files)} files uploaded successfully',
            'note_count': len(uploaded_notes),
            'note_ids': uploaded_notes
        })
    
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def start_study_session_api(request):
    """API endpoint to start a new study session"""
    
    flashcard_ids = request.data.get('flashcard_ids', [])
    session_name = request.data.get('session_name', 'Study Session')
    
    if not flashcard_ids:
        return Response({
            'error': 'No flashcards provided'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Validate flashcards belong to user
    flashcards = Flashcard.objects.filter(
        id__in=flashcard_ids,
        note__uploaded_by=request.user
    )
    
    if flashcards.count() != len(flashcard_ids):
        return Response({
            'error': 'Some flashcards not found or not accessible'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Create study session
    session = StudySession.objects.create(
        user=request.user,
        session_name=session_name,
        total_cards=len(flashcard_ids)
    )
    
    # Add flashcards to session
    session.flashcards.set(flashcards)
    
    # Log activity
    UserActivity.objects.create(
        user=request.user,
        activity_type='study_session',
        description=f"Started study session: {session_name}",
        metadata={
            'session_id': session.id,
            'flashcard_count': len(flashcard_ids)
        }
    )
    
    return Response({
        'success': True,
        'session_id': session.id,
        'session_name': session.session_name,
        'total_cards': session.total_cards,
        'flashcards': [
            {
                'id': fc.id,
                'question': fc.question,
                'answer': fc.answer,
                'difficulty': fc.difficulty
            }
            for fc in flashcards
        ]
    })


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def submit_flashcard_answer_api(request, session_id, flashcard_id):
    """API endpoint to submit flashcard answer during study session"""
    
    session = get_object_or_404(StudySession, id=session_id, user=request.user)
    flashcard = get_object_or_404(Flashcard, id=flashcard_id)
    
    answered_correctly = request.data.get('answered_correctly')
    response_time = request.data.get('response_time_seconds', 0)
    
    if answered_correctly is None:
        return Response({
            'error': 'answered_correctly field is required'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Update or create study session flashcard record
    from ai_processing.models import StudySessionFlashcard
    session_flashcard, created = StudySessionFlashcard.objects.get_or_create(
        study_session=session,
        flashcard=flashcard,
        defaults={
            'answered_correctly': answered_correctly,
            'response_time_seconds': response_time
        }
    )
    
    if not created:
        session_flashcard.answered_correctly = answered_correctly
        session_flashcard.response_time_seconds = response_time
        session_flashcard.save()
    
    # Update flashcard statistics
    flashcard.times_reviewed += 1
    if answered_correctly:
        flashcard.times_correct += 1
        session.correct_answers += 1
    
    flashcard.last_reviewed = session_flashcard.answered_at
    flashcard.save()
    session.save()
    
    return Response({
        'success': True,
        'flashcard_id': flashcard.id,
        'success_rate': flashcard.success_rate,
        'session_progress': {
            'answered': StudySessionFlashcard.objects.filter(study_session=session).count(),
            'total': session.total_cards,
            'correct': session.correct_answers
        }
    })


@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def complete_study_session_api(request, session_id):
    """API endpoint to complete a study session"""
    
    session = get_object_or_404(StudySession, id=session_id, user=request.user)
    
    if session.completed:
        return Response({
            'error': 'Session already completed'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    # Mark session as completed
    session.completed = True
    session.completed_at = timezone.now()
    
    # Calculate duration
    if session.started_at:
        duration = (session.completed_at - session.started_at).total_seconds()
        session.duration_seconds = int(duration)
    
    session.save()
    
    return Response({
        'success': True,
        'session_id': session.id,
        'score_percentage': session.score_percentage,
        'correct_answers': session.correct_answers,
        'total_cards': session.total_cards,
        'duration_seconds': session.duration_seconds
    })


@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def user_stats_api(request):
    """API endpoint to get user statistics"""
    
    from dashboard.models import UserStudyStatistics
    
    stats, created = UserStudyStatistics.objects.get_or_create(user=request.user)
    
    return Response({
        'total_notes_uploaded': stats.total_notes_uploaded,
        'total_notes_processed': stats.total_notes_processed,
        'total_summaries_generated': stats.total_summaries_generated,
        'total_flashcards_created': stats.total_flashcards_created,
        'total_flashcards_studied': stats.total_flashcards_studied,
        'total_study_sessions': stats.total_study_sessions,
        'total_study_time_minutes': stats.total_study_time_minutes,
        'average_session_score': stats.average_session_score,
        'current_study_streak': stats.current_study_streak,
        'longest_study_streak': stats.longest_study_streak,
        'overall_accuracy': stats.overall_accuracy,
        'notes_processing_rate': stats.notes_processing_rate
    })