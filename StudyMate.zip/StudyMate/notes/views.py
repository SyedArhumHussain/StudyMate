from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.core.paginator import Paginator
from .models import Note, Subject, Tag
from .forms import NoteUploadForm, NoteEditForm
from ai_processing.tasks import process_note_content_async
from dashboard.models import UserActivity
import json


@login_required
def note_list(request):
    """Display list of user's notes"""
    notes = Note.objects.filter(uploaded_by=request.user)
    
    # Filter by subject if specified
    subject_id = request.GET.get('subject')
    if subject_id:
        notes = notes.filter(subject_id=subject_id)
    
    # Filter by status if specified
    status = request.GET.get('status')
    if status:
        notes = notes.filter(status=status)
    
    # Search functionality
    search = request.GET.get('search')
    if search:
        notes = notes.filter(title__icontains=search)
    
    # Pagination
    paginator = Paginator(notes, 12)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Get user's subjects for filtering
    subjects = Subject.objects.filter(created_by=request.user)
    
    context = {
        'page_obj': page_obj,
        'subjects': subjects,
        'current_subject': subject_id,
        'current_status': status,
        'search_query': search,
    }
    
    return render(request, 'notes/note_list.html', context)


@login_required
def note_detail(request, note_id):
    """Display detailed view of a note"""
    note = get_object_or_404(Note, id=note_id, uploaded_by=request.user)
    
    # Log activity
    UserActivity.objects.create(
        user=request.user,
        activity_type='note_view',
        description=f"Viewed note: {note.title}",
        note=note,
        subject=note.subject
    )
    
    context = {
        'note': note,
        'has_summary': hasattr(note, 'summary'),
        'flashcards': note.flashcards.all()[:10],  # Show first 10 flashcards
        'flashcard_count': note.flashcards.count(),
    }
    
    return render(request, 'notes/note_detail.html', context)


@login_required
def note_upload(request):
    """Handle note upload"""
    if request.method == 'POST':
        form = NoteUploadForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            note = form.save(commit=False)
            note.uploaded_by = request.user
            
            # Handle optional subject - create/get default if none selected
            print(f"DEBUG: note.subject before check: {note.subject}")
            if not note.subject:
                print("DEBUG: Creating default subject")
                default_subject, created = Subject.objects.get_or_create(
                    name='General',
                    created_by=request.user,
                    defaults={
                        'description': 'Default subject for uncategorized notes',
                        'color': '#6c757d'
                    }
                )
                note.subject = default_subject
                print(f"DEBUG: Set subject to: {note.subject}")
            else:
                print(f"DEBUG: Subject already set: {note.subject}")
            
            # Determine content type based on file extension or content
            if note.file:
                file_ext = note.file.name.split('.')[-1].lower()
                if file_ext == 'pdf':
                    note.content_type = 'pdf'
                elif file_ext in ['png', 'jpg', 'jpeg']:
                    note.content_type = 'image'
                else:
                    note.content_type = 'text'
            else:
                note.content_type = 'text'
            
            note.save()
            
            # Log activity
            UserActivity.objects.create(
                user=request.user,
                activity_type='note_upload',
                description=f"Uploaded note: {note.title}",
                note=note,
                subject=note.subject,
                metadata={'file_size': note.file_size if note.file else 0}
            )
            
            # Start async processing (handle Redis connection gracefully)
            try:
                process_note_content_async.delay(note.id)
                messages.success(request, f'Note "{note.title}" uploaded successfully! Processing will begin shortly.')
            except Exception as e:
                # If Redis/Celery is not available, still allow upload but notify user
                print(f"WARNING: Could not start async processing: {e}")
                messages.success(request, f'Note "{note.title}" uploaded successfully! (AI processing unavailable - Redis not running)')
            
            return redirect('note_detail', note_id=note.id)
    else:
        form = NoteUploadForm(user=request.user)
    
    return render(request, 'notes/note_upload.html', {'form': form})


@login_required
def note_edit(request, note_id):
    """Edit an existing note"""
    note = get_object_or_404(Note, id=note_id, uploaded_by=request.user)
    
    if request.method == 'POST':
        form = NoteEditForm(request.POST, instance=note, user=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Note updated successfully!')
            return redirect('note_detail', note_id=note.id)
    else:
        form = NoteEditForm(instance=note, user=request.user)
    
    return render(request, 'notes/note_edit.html', {'form': form, 'note': note})


@login_required
def note_delete(request, note_id):
    """Delete a note"""
    note = get_object_or_404(Note, id=note_id, uploaded_by=request.user)
    
    if request.method == 'POST':
        title = note.title
        note.delete()
        messages.success(request, f'Note "{title}" deleted successfully!')
        return redirect('note_list')
    
    return render(request, 'notes/note_confirm_delete.html', {'note': note})


@login_required
@require_http_methods(["POST"])
def reprocess_note(request, note_id):
    """Trigger reprocessing of a note"""
    note = get_object_or_404(Note, id=note_id, uploaded_by=request.user)
    
    # Clear existing processing results
    if hasattr(note, 'summary'):
        note.summary.delete()
    note.flashcards.all().delete()
    
    # Reset flags
    note.is_summarized = False
    note.has_flashcards = False
    note.status = 'uploaded'
    note.save()
    
    # Start async processing (handle Redis connection gracefully)
    try:
        process_note_content_async.delay(note.id)
        return JsonResponse({
            'success': True,
            'message': 'Note reprocessing started!'
        })
    except Exception as e:
        print(f"WARNING: Could not start async reprocessing: {e}")
        return JsonResponse({
            'success': False,
            'message': 'AI processing unavailable - Redis not running'
        })


@login_required
def note_processing_status(request, note_id):
    """Get processing status of a note"""
    note = get_object_or_404(Note, id=note_id, uploaded_by=request.user)
    
    return JsonResponse({
        'status': note.status,
        'is_summarized': note.is_summarized,
        'has_flashcards': note.has_flashcards,
        'flashcard_count': note.flashcards.count(),
        'processing_logs': [
            {
                'process_type': log.process_type,
                'status': log.status,
                'started_at': log.started_at.isoformat(),
                'error_message': log.error_message
            }
            for log in note.processing_logs.all()[:5]  # Last 5 logs
        ]
    })


@login_required
def subject_list(request):
    """Display list of user's subjects"""
    subjects = Subject.objects.filter(created_by=request.user)
    
    # Add note counts to subjects
    for subject in subjects:
        subject.note_count = subject.notes.count()
        subject.processed_count = subject.notes.filter(status='processed').count()
    
    return render(request, 'notes/subject_list.html', {'subjects': subjects})


@login_required
def subject_create(request):
    """Create a new subject"""
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('description', '')
        color = request.POST.get('color', '#007bff')
        
        if name:
            subject = Subject.objects.create(
                name=name,
                description=description,
                color=color,
                created_by=request.user
            )
            
            messages.success(request, f'Subject "{subject.name}" created successfully!')
            return redirect('subject_list')
        else:
            messages.error(request, 'Subject name is required.')
    
    return render(request, 'notes/subject_create.html')


@login_required
def bulk_upload(request):
    """Handle bulk upload of multiple files"""
    if request.method == 'POST':
        files = request.FILES.getlist('files')
        subject_id = request.POST.get('subject')
        
        if not files:
            messages.error(request, 'No files selected.')
            return redirect('bulk_upload')
        
        if not subject_id:
            messages.error(request, 'Please select a subject.')
            return redirect('bulk_upload')
        
        subject = get_object_or_404(Subject, id=subject_id, created_by=request.user)
        
        uploaded_notes = []
        for file in files:
            # Create note for each file
            note = Note.objects.create(
                title=file.name.split('.')[0],  # Use filename as title
                uploaded_by=request.user,
                subject=subject,
                file=file,
                content_type='pdf' if file.name.endswith('.pdf') else 'text'
            )
            uploaded_notes.append(note.id)
        
        # Start batch processing
        from ai_processing.tasks import batch_process_notes
        batch_process_notes.delay(uploaded_notes)
        
        messages.success(request, f'{len(files)} files uploaded successfully! Processing will begin shortly.')
        return redirect('note_list')
    
    subjects = Subject.objects.filter(created_by=request.user)
    return render(request, 'notes/bulk_upload.html', {'subjects': subjects})
