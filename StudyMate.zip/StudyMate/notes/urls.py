from django.urls import path, include
from . import views, api_views

app_name = 'notes'

# Regular web URLs
urlpatterns = [
    # Note URLs
    path('', views.note_list, name='list'),
    path('upload/', views.note_upload, name='upload'),
    path('bulk-upload/', views.bulk_upload, name='bulk_upload'),
    path('<int:note_id>/', views.note_detail, name='detail'),
    path('<int:note_id>/edit/', views.note_edit, name='note_edit'),
    path('<int:note_id>/delete/', views.note_delete, name='note_delete'),
    path('<int:note_id>/reprocess/', views.reprocess_note, name='reprocess_note'),
    path('<int:note_id>/status/', views.note_processing_status, name='note_processing_status'),
    
    # Subject URLs
    path('subjects/', views.subject_list, name='subject_list'),
    path('subjects/create/', views.subject_create, name='subject_create'),
]

# API URLs
api_urlpatterns = [
    # Note API endpoints
    path('notes/', api_views.NoteListCreateAPIView.as_view(), name='api_note_list_create'),
    path('notes/<int:pk>/', api_views.NoteDetailAPIView.as_view(), name='api_note_detail'),
    path('notes/<int:note_id>/reprocess/', api_views.reprocess_note_api, name='api_reprocess_note'),
    path('notes/<int:note_id>/status/', api_views.note_processing_status_api, name='api_note_status'),
    path('notes/bulk-upload/', api_views.bulk_upload_api, name='api_bulk_upload'),
    
    # Subject API endpoints
    path('subjects/', api_views.SubjectListCreateAPIView.as_view(), name='api_subject_list_create'),
    path('subjects/<int:pk>/', api_views.SubjectDetailAPIView.as_view(), name='api_subject_detail'),
    
    # Flashcard API endpoints
    path('flashcards/', api_views.FlashcardListAPIView.as_view(), name='api_flashcard_list'),
    
    # Study session API endpoints
    path('study-sessions/start/', api_views.start_study_session_api, name='api_start_study_session'),
    path('study-sessions/<int:session_id>/flashcards/<int:flashcard_id>/answer/', 
         api_views.submit_flashcard_answer_api, name='api_submit_flashcard_answer'),
    path('study-sessions/<int:session_id>/complete/', 
         api_views.complete_study_session_api, name='api_complete_study_session'),
    
    # User statistics
    path('stats/', api_views.user_stats_api, name='api_user_stats'),
]

# Include API URLs under 'api/' prefix
urlpatterns += [
    path('api/', include(api_urlpatterns)),
]