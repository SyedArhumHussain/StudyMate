# Manual migration to create default subject for existing notes
from django.db import migrations, models
import django.db.models.deletion

def create_default_subject(apps, schema_editor):
    Subject = apps.get_model('core', 'Subject')
    Note = apps.get_model('notes', 'Note')
    User = apps.get_model('core', 'User')
    
    # Get all users and create a default subject for each
    for user in User.objects.all():
        default_subject, created = Subject.objects.get_or_create(
            name='General',
            created_by=user,
            defaults={
                'description': 'Default subject for uncategorized notes',
                'color': '#6c757d'
            }
        )
        
        # Update any notes that might not have a subject (shouldn't exist yet but just in case)
        Note.objects.filter(uploaded_by=user, subject__isnull=True).update(subject=default_subject)

def reverse_create_default_subject(apps, schema_editor):
    # Don't delete anything on reverse - we don't want to lose data
    pass

class Migration(migrations.Migration):
    
    dependencies = [
        ('notes', '0002_alter_note_subject'),
        ('core', '0001_initial'),
    ]
    
    operations = [
        migrations.RunPython(create_default_subject, reverse_create_default_subject),
    ]