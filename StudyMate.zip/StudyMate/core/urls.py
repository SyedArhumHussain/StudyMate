from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    # Authentication
    path('register/', views.register, name='register'),
    path('profile/', views.profile, name='profile'),
    path('delete-account/', views.delete_account, name='delete_account'),
    
    # API endpoints
    path('api/profile/', views.profile_api, name='api_profile'),
    path('api/check-email/', views.check_email_availability, name='api_check_email'),
    path('api/check-username/', views.check_username_availability, name='api_check_username'),
]