from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from .forms import UserRegistrationForm, UserProfileForm
from .models import User
from dashboard.models import UserStudyStatistics, UserActivity


def register(request):
    """User registration view"""
    if request.user.is_authenticated:
        return redirect('dashboard:dashboard')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            # Create user statistics record
            UserStudyStatistics.objects.create(user=user)
            
            # Log registration activity
            UserActivity.objects.create(
                user=user,
                activity_type='login',
                description='User registered and logged in'
            )
            
            # Authenticate and login user
            username = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            if user:
                login(request, user)
                messages.success(request, f'Welcome to StudyMate, {user.first_name}!')
                return redirect('dashboard:dashboard')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'registration/register.html', {'form': form})


@login_required
def profile(request):
    """User profile view"""
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('core:profile')
    else:
        form = UserProfileForm(instance=request.user)
    
    context = {
        'form': form,
        'user': request.user
    }
    return render(request, 'core/profile.html', context)


@login_required
def profile_api(request):
    """API endpoint for user profile"""
    if request.method == 'GET':
        return JsonResponse({
            'id': request.user.id,
            'username': request.user.username,
            'email': request.user.email,
            'first_name': request.user.first_name,
            'last_name': request.user.last_name,
            'date_joined': request.user.date_joined.isoformat(),
            'is_student': request.user.is_student
        })
    
    elif request.method == 'PUT':
        import json
        try:
            data = json.loads(request.body)
            user = request.user
            
            # Update allowed fields
            if 'first_name' in data:
                user.first_name = data['first_name']
            if 'last_name' in data:
                user.last_name = data['last_name']
            if 'email' in data:
                # Check if email already exists
                if User.objects.filter(email=data['email']).exclude(id=user.id).exists():
                    return JsonResponse({
                        'error': 'Email already in use'
                    }, status=400)
                user.email = data['email']
            
            user.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Profile updated successfully'
            })
            
        except json.JSONDecodeError:
            return JsonResponse({
                'error': 'Invalid JSON data'
            }, status=400)
        except Exception as e:
            return JsonResponse({
                'error': str(e)
            }, status=400)
    
    return JsonResponse({
        'error': 'Method not allowed'
    }, status=405)


@login_required
def delete_account(request):
    """Delete user account"""
    if request.method == 'POST':
        user = request.user
        username = user.username
        
        # Log out user and delete account
        user.delete()
        
        messages.success(request, f'Account for {username} has been deleted successfully.')
        return redirect('login')
    
    return render(request, 'core/delete_account.html')


@require_http_methods(["GET"])
def check_email_availability(request):
    """API endpoint to check if email is available"""
    email = request.GET.get('email')
    if not email:
        return JsonResponse({'error': 'Email parameter required'}, status=400)
    
    exists = User.objects.filter(email=email).exists()
    return JsonResponse({
        'available': not exists,
        'email': email
    })


@require_http_methods(["GET"])
def check_username_availability(request):
    """API endpoint to check if username is available"""
    username = request.GET.get('username')
    if not username:
        return JsonResponse({'error': 'Username parameter required'}, status=400)
    
    exists = User.objects.filter(username=username).exists()
    return JsonResponse({
        'available': not exists,
        'username': username
    })
