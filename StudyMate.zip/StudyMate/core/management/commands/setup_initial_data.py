from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from core.models import Subject
from notes.models import Note
from dashboard.models import UserStudyStatistics

User = get_user_model()


class Command(BaseCommand):
    help = 'Set up initial data for StudyMate'

    def add_arguments(self, parser):
        parser.add_argument(
            '--admin-email',
            type=str,
            default='admin@studymate.com',
            help='Admin email address'
        )
        parser.add_argument(
            '--admin-password',
            type=str,
            default='admin123',
            help='Admin password'
        )

    def handle(self, *args, **options):
        # Create superuser
        if not User.objects.filter(email=options['admin_email']).exists():
            admin_user = User.objects.create_superuser(
                username='admin',
                email=options['admin_email'],
                password=options['admin_password'],
                first_name='Admin',
                last_name='User'
            )
            self.stdout.write(
                self.style.SUCCESS(f'Created superuser: {options["admin_email"]}')
            )
        else:
            admin_user = User.objects.get(email=options['admin_email'])
            self.stdout.write(
                self.style.WARNING(f'Superuser already exists: {options["admin_email"]}')
            )

        # Create demo user
        if not User.objects.filter(email='demo@studymate.com').exists():
            demo_user = User.objects.create_user(
                username='demo',
                email='demo@studymate.com',
                password='demo123',
                first_name='Demo',
                last_name='Student',
                is_student=True
            )
            
            # Create user statistics
            UserStudyStatistics.objects.create(user=demo_user)
            
            # Create sample subjects
            subjects = [
                {'name': 'Computer Science', 'description': 'Programming and algorithms', 'color': '#007bff'},
                {'name': 'Mathematics', 'description': 'Calculus and linear algebra', 'color': '#28a745'},
                {'name': 'Physics', 'description': 'Classical and quantum physics', 'color': '#dc3545'},
                {'name': 'Chemistry', 'description': 'Organic and inorganic chemistry', 'color': '#ffc107'},
            ]
            
            for subject_data in subjects:
                subject = Subject.objects.create(
                    created_by=demo_user,
                    **subject_data
                )
            
            # Create sample note
            cs_subject = Subject.objects.get(name='Computer Science', created_by=demo_user)
            Note.objects.create(
                title='Introduction to Python',
                description='Basic Python concepts and syntax',
                content_type='text',
                text_content='''
# Introduction to Python

Python is a high-level, interpreted programming language known for its simplicity and readability.

## Key Features:
- Easy to learn and use
- Interpreted language
- Dynamic typing
- Large standard library
- Cross-platform compatibility

## Basic Syntax:
```python
# Variables
name = "StudyMate"
version = 1.0

# Functions
def greet(name):
    return f"Hello, {name}!"

# Classes
class Student:
    def __init__(self, name):
        self.name = name
    
    def study(self):
        print(f"{self.name} is studying!")
```

## Data Types:
1. **Numbers**: int, float, complex
2. **Strings**: text data
3. **Lists**: ordered collections
4. **Tuples**: immutable sequences  
5. **Dictionaries**: key-value pairs
6. **Sets**: unordered unique elements

## Control Structures:
- if/elif/else statements
- for and while loops
- try/except for error handling

Python's philosophy emphasizes code readability and simplicity, making it an excellent choice for beginners and experienced programmers alike.
                ''',
                uploaded_by=demo_user,
                subject=cs_subject,
                status='uploaded'
            )
            
            self.stdout.write(
                self.style.SUCCESS(f'Created demo user: demo@studymate.com')
            )
            self.stdout.write(
                self.style.SUCCESS(f'Created {len(subjects)} sample subjects')
            )
            self.stdout.write(
                self.style.SUCCESS('Created sample note')
            )
        else:
            self.stdout.write(
                self.style.WARNING('Demo user already exists')
            )

        self.stdout.write(
            self.style.SUCCESS('Initial data setup completed!')
        )
        self.stdout.write(
            self.style.SUCCESS('=== LOGIN CREDENTIALS ===')
        )
        self.stdout.write(f'Admin: {options["admin_email"]} / {options["admin_password"]}')
        self.stdout.write('Demo: demo@studymate.com / demo123')