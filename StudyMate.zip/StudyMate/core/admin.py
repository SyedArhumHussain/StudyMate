from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Subject


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_student', 'date_joined')
    list_filter = ('is_student', 'is_staff', 'is_active', 'date_joined')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)
    
    fieldsets = UserAdmin.fieldsets + (
        ('Student Info', {'fields': ('is_student',)}),
    )


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_by', 'color', 'created_at')
    list_filter = ('created_at', 'created_by')
    search_fields = ('name', 'description', 'created_by__username')
    ordering = ('-created_at',)
