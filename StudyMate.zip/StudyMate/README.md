# StudyMate - AI-Powered Student Portal

StudyMate is a comprehensive Django-based student portal that leverages Claude AI to help students organize, process, and study their notes more effectively through AI-generated summaries and flashcards.

## 🚀 Features

### Core Functionality
- **Note Management**: Upload and organize notes in various formats (PDF, text, images)
- **AI Content Processing**: Automatic text extraction and intelligent content analysis
- **Smart Summaries**: AI-generated summaries with key points extraction
- **Interactive Flashcards**: Q&A format flashcards with difficulty levels
- **Study Sessions**: Structured study sessions with progress tracking
- **Subject Organization**: Organize notes by subjects with color coding

### AI-Powered Features
- **Claude API Integration**: Uses Anthropic's Claude for content processing
- **Automatic Summarization**: Brief, detailed, or key-points summaries
- **Flashcard Generation**: Intelligent Q&A pairs with varied question types
- **Content Analysis**: Key concept extraction and categorization
- **Progress Insights**: AI-powered study recommendations

### Dashboard & Analytics
- **Interactive Dashboard**: Personalized student dashboard with widgets
- **Study Statistics**: Track study sessions, accuracy, and progress
- **Subject Progress**: Per-subject analytics and performance metrics
- **Goal Setting**: Create and track study goals
- **Activity Timeline**: Complete history of study activities

### Technical Features
- **REST API**: Comprehensive API for all functionality
- **Async Processing**: Background task processing with Celery
- **File Upload**: Secure file handling with validation
- **Responsive Design**: Mobile-friendly interface
- **User Authentication**: Secure registration and login system

## 🛠️ Technology Stack

- **Backend**: Django 4.2.7 + Django REST Framework
- **Database**: SQLite (development) / PostgreSQL (production)
- **AI Integration**: Anthropic Claude API
- **Task Queue**: Celery + Redis
- **File Processing**: PyPDF2 for PDF text extraction
- **Frontend**: Django Templates with Bootstrap (responsive)
- **Authentication**: Django's built-in auth system

## 📋 Installation & Setup

### Prerequisites
- Python 3.12+
- Redis (for Celery)
- Claude API key from Anthropic

### Installation Steps

1. **Clone and setup the project**:
   ```bash
   cd StudyMate
   pip install -r requirements.txt
   ```

2. **Configure environment variables**:
   Edit `.env` file and add your Claude API key:
   ```
   ANTHROPIC_API_KEY=your-claude-api-key-here
   ```

3. **Run database migrations**:
   ```bash
   python manage.py migrate
   ```

4. **Create initial data** (includes admin and demo users):
   ```bash
   python manage.py setup_initial_data
   ```

5. **Start the development server**:
   ```bash
   python manage.py runserver
   ```

6. **Start Celery worker** (in a separate terminal):
   ```bash
   celery -A StudyMate worker -l info
   ```

### Login Credentials
- **Admin**: admin@studymate.com / admin123
- **Demo Student**: demo@studymate.com / demo123

## 🏗️ Project Structure

```
StudyMate/
├── core/                   # User management and authentication
├── notes/                  # Note upload and management
├── ai_processing/          # AI services and flashcard management
├── dashboard/              # Dashboard and analytics
├── StudyMate/             # Main project settings
├── static/                # Static files (CSS, JS, images)
├── media/                 # Uploaded files
├── templates/             # HTML templates
└── requirements.txt       # Python dependencies
```

## 📊 Database Models

### Core Models
- **User**: Extended Django user with student-specific fields
- **Subject**: Study subjects with color coding
- **Note**: Uploaded notes with metadata and processing status

### AI Processing Models
- **Summary**: AI-generated summaries with key points
- **Flashcard**: Q&A flashcards with difficulty and performance tracking
- **StudySession**: Study session management and results
- **AIProcessingLog**: Detailed logs of AI processing operations

### Dashboard Models
- **UserActivity**: Activity tracking and timeline
- **UserStudyStatistics**: Comprehensive study statistics
- **StudyGoal**: Goal setting and progress tracking
- **DashboardWidget**: Customizable dashboard widgets

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/login/` - User login
- `POST /api/auth/logout/` - User logout
- `GET /api/profile/` - Get user profile

### Notes Management
- `GET /notes/api/notes/` - List user's notes
- `POST /notes/api/notes/` - Upload new note
- `GET /notes/api/notes/{id}/` - Get note details
- `POST /notes/api/notes/{id}/reprocess/` - Reprocess note with AI

### Study Features
- `GET /notes/api/flashcards/` - List flashcards
- `POST /notes/api/study-sessions/start/` - Start study session
- `POST /notes/api/study-sessions/{id}/complete/` - Complete session

### Analytics
- `GET /dashboard/api/stats/` - User statistics
- `GET /dashboard/api/subject-progress/` - Subject progress data

## 🤖 AI Processing Workflow

1. **File Upload**: User uploads a note or PDF
2. **Text Extraction**: System extracts text content from files
3. **AI Processing**: Claude API processes content for:
   - Summary generation
   - Key points extraction
   - Flashcard creation
4. **Storage**: Results stored in database with metadata
5. **User Access**: Students can review and study processed content

## 📱 Key Features Walkthrough

### Note Upload Process
1. Student uploads a PDF or enters text
2. System automatically determines content type
3. Background task processes content with AI
4. Student receives summary and flashcards
5. Content becomes available for study sessions

### Study Session Flow
1. Student selects study type (new cards, review, mixed)
2. System creates session with appropriate flashcards
3. Student goes through Q&A pairs
4. System tracks performance and updates statistics
5. Session results saved for progress tracking

### Dashboard Analytics
- Study streak tracking
- Performance metrics per subject
- Goal progress visualization
- Recent activity timeline
- Flashcard review recommendations

## 🔧 Configuration

### Production Deployment
1. Switch to PostgreSQL in settings.py
2. Configure Redis for Celery
3. Set up proper static file serving
4. Configure ALLOWED_HOSTS
5. Enable HTTPS and security settings

### Claude API Configuration
- Get API key from Anthropic Console
- Add to environment variables
- Configure rate limits and error handling
- Monitor usage and costs

## 🧪 Testing

Run the test suite:
```bash
python manage.py test
```

## 📈 Performance Considerations

- **Async Processing**: Heavy AI operations run in background
- **Caching**: Redis caching for frequently accessed data
- **File Optimization**: Compressed file storage and delivery
- **Database Indexing**: Optimized queries with proper indexes

## 🛡️ Security Features

- **Input Validation**: All forms include comprehensive validation
- **File Upload Security**: File type and size restrictions
- **Authentication**: Session-based authentication
- **API Security**: Token-based API authentication
- **SQL Injection Protection**: Django ORM prevents SQL injection

## 🚀 Future Enhancements

- **Mobile App**: React Native mobile application
- **Voice Notes**: Audio recording and transcription
- **Collaborative Study**: Group study sessions and sharing
- **Advanced Analytics**: ML-powered study recommendations
- **Integration**: Calendar and LMS integrations
- **Offline Support**: PWA capabilities for offline study

## 📝 License

This project is created for educational purposes as a demonstration of Django development with AI integration.

---

**StudyMate** - Empowering students with AI-powered learning tools! 📚🤖