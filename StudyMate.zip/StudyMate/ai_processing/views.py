from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.core.paginator import Paginator
from .models import Flashcard, StudySession, AIProcessingLog
from .forms import FlashcardEditForm
from notes.models import Note


@login_required
def flashcard_list(request):
    """List all user's flashcards"""
    flashcards = Flashcard.objects.filter(note__uploaded_by=request.user).select_related('note', 'note__subject')
    
    # Filter by subject if specified
    subject_id = request.GET.get('subject')
    if subject_id:
        flashcards = flashcards.filter(note__subject_id=subject_id)
    
    # Filter by difficulty if specified
    difficulty = request.GET.get('difficulty')
    if difficulty:
        flashcards = flashcards.filter(difficulty=difficulty)
    
    # Search functionality
    search = request.GET.get('search')
    if search:
        flashcards = flashcards.filter(question__icontains=search)
    
    # Pagination
    paginator = Paginator(flashcards, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Get user's subjects for filtering
    from notes.models import Subject
    subjects = Subject.objects.filter(created_by=request.user)
    
    context = {
        'page_obj': page_obj,
        'subjects': subjects,
        'current_subject': subject_id,
        'current_difficulty': difficulty,
        'search_query': search,
        'difficulty_choices': Flashcard.DIFFICULTY_CHOICES,
    }
    
    return render(request, 'ai_processing/flashcard_list.html', context)


@login_required
def flashcard_detail(request, flashcard_id):
    """Display detailed view of a flashcard"""
    flashcard = get_object_or_404(Flashcard, id=flashcard_id, note__uploaded_by=request.user)
    
    context = {
        'flashcard': flashcard,
        'note': flashcard.note,
    }
    
    return render(request, 'ai_processing/flashcard_detail.html', context)


@login_required
def flashcard_edit(request, flashcard_id):
    """Edit a flashcard"""
    flashcard = get_object_or_404(Flashcard, id=flashcard_id, note__uploaded_by=request.user)
    
    if request.method == 'POST':
        form = FlashcardEditForm(request.POST, instance=flashcard)
        if form.is_valid():
            form.save()
            messages.success(request, 'Flashcard updated successfully!')
            return redirect('ai_processing:flashcard_detail', flashcard_id=flashcard.id)
    else:
        form = FlashcardEditForm(instance=flashcard)
    
    return render(request, 'ai_processing/flashcard_edit.html', {
        'form': form, 
        'flashcard': flashcard
    })


@login_required
def flashcard_delete(request, flashcard_id):
    """Delete a flashcard"""
    flashcard = get_object_or_404(Flashcard, id=flashcard_id, note__uploaded_by=request.user)
    
    if request.method == 'POST':
        note_title = flashcard.note.title
        flashcard.delete()
        messages.success(request, f'Flashcard from "{note_title}" deleted successfully!')
        return redirect('ai_processing:flashcard_list')
    
    return render(request, 'ai_processing/flashcard_confirm_delete.html', {'flashcard': flashcard})


@login_required
def study_session_list(request):
    """List user's study sessions"""
    sessions = StudySession.objects.filter(user=request.user).order_by('-started_at')
    
    # Pagination
    paginator = Paginator(sessions, 15)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
    }
    
    return render(request, 'ai_processing/study_session_list.html', context)


@login_required
def study_session_detail(request, session_id):
    """Display detailed view of a study session"""
    session = get_object_or_404(StudySession, id=session_id, user=request.user)
    
    # Get session results
    from .models import StudySessionFlashcard
    session_results = StudySessionFlashcard.objects.filter(
        study_session=session
    ).select_related('flashcard').order_by('answered_at')
    
    context = {
        'session': session,
        'session_results': session_results,
        'total_answered': session_results.count(),
        'correct_count': session_results.filter(answered_correctly=True).count(),
    }
    
    return render(request, 'ai_processing/study_session_detail.html', context)


@login_required
def processing_logs(request):
    """List AI processing logs"""
    logs = AIProcessingLog.objects.filter(note__uploaded_by=request.user).select_related('note').order_by('-started_at')
    
    # Filter by process type if specified
    process_type = request.GET.get('process_type')
    if process_type:
        logs = logs.filter(process_type=process_type)
    
    # Filter by status if specified
    status = request.GET.get('status')
    if status:
        logs = logs.filter(status=status)
    
    # Pagination
    paginator = Paginator(logs, 25)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'current_process_type': process_type,
        'current_status': status,
        'process_type_choices': AIProcessingLog.PROCESS_TYPE_CHOICES,
        'status_choices': AIProcessingLog.STATUS_CHOICES,
    }
    
    return render(request, 'ai_processing/processing_logs.html', context)


@login_required
def processing_log_detail(request, log_id):
    """Display detailed view of a processing log"""
    log = get_object_or_404(AIProcessingLog, id=log_id, note__uploaded_by=request.user)
    
    context = {
        'log': log,
        'note': log.note,
    }
    
    return render(request, 'ai_processing/processing_log_detail.html', context)
