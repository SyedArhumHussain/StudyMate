from django.urls import path
from . import views

app_name = 'ai_processing'

urlpatterns = [
    # Flashcard management
    path('flashcards/', views.flashcard_list, name='flashcard_list'),
    path('flashcards/<int:flashcard_id>/', views.flashcard_detail, name='flashcard_detail'),
    path('flashcards/<int:flashcard_id>/edit/', views.flashcard_edit, name='flashcard_edit'),
    path('flashcards/<int:flashcard_id>/delete/', views.flashcard_delete, name='flashcard_delete'),
    
    # Study sessions
    path('sessions/', views.study_session_list, name='study_session_list'),
    path('sessions/<int:session_id>/', views.study_session_detail, name='study_session_detail'),
    
    # Processing logs
    path('logs/', views.processing_logs, name='processing_logs'),
    path('logs/<int:log_id>/', views.processing_log_detail, name='processing_log_detail'),
]