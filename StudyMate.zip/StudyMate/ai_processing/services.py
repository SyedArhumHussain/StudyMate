import time
import logging
from typing import Dict, List, Optional, Tuple
from django.conf import settings
import anthropic
import PyPDF2
import io
from PIL import Image
import json

logger = logging.getLogger(__name__)


class ClaudeAPIService:
    """Service class for interacting with Claude API"""
    
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
        self.model = "claude-3-haiku-20240307"
    
    def _make_api_call(self, messages: List[Dict], max_tokens: int = 4000) -> Tuple[str, Dict]:
        """Make API call to Claude and return response with metadata"""
        start_time = time.time()
        
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                messages=messages
            )
            
            processing_time = time.time() - start_time
            
            metadata = {
                'processing_time': processing_time,
                'tokens_used': response.usage.input_tokens + response.usage.output_tokens,
                'model_used': self.model
            }
            
            return response.content[0].text, metadata
            
        except Exception as e:
            logger.error(f"Claude API call failed: {str(e)}")
            raise
    
    def generate_summary(self, content: str, summary_type: str = 'brief') -> Tuple[str, List[str], Dict]:
        """Generate summary and key points from content"""
        
        prompts = {
            'brief': """Please provide a brief summary of the following content in 2-3 paragraphs. 
                       Focus on the main ideas and key concepts. Also extract 5-7 key points as a bulleted list.
                       
                       Format your response as:
                       SUMMARY:
                       [Your summary here]
                       
                       KEY_POINTS:
                       • [Point 1]
                       • [Point 2]
                       etc.""",
            
            'detailed': """Please provide a detailed summary of the following content. 
                          Include all important concepts, explanations, and examples.
                          Also extract 8-12 key points as a bulleted list.
                          
                          Format your response as:
                          SUMMARY:
                          [Your detailed summary here]
                          
                          KEY_POINTS:
                          • [Point 1]
                          • [Point 2]
                          etc.""",
            
            'key_points': """Please extract the main key points from the following content.
                           Provide 10-15 key points as a bulleted list, and a brief overview.
                           
                           Format your response as:
                           SUMMARY:
                           [Brief overview here]
                           
                           KEY_POINTS:
                           • [Point 1]
                           • [Point 2]
                           etc."""
        }
        
        prompt = prompts.get(summary_type, prompts['brief'])
        
        messages = [
            {
                "role": "user",
                "content": f"{prompt}\n\nContent:\n{content}"
            }
        ]
        
        response_text, metadata = self._make_api_call(messages)
        
        # Parse the response
        parts = response_text.split('KEY_POINTS:')
        if len(parts) == 2:
            summary = parts[0].replace('SUMMARY:', '').strip()
            key_points_text = parts[1].strip()
            key_points = [point.strip('• ').strip() for point in key_points_text.split('\n') if point.strip().startswith('•')]
        else:
            summary = response_text
            key_points = []
        
        return summary, key_points, metadata
    
    def generate_flashcards(self, content: str, num_cards: int = 10) -> Tuple[List[Dict], Dict]:
        """Generate flashcards from content"""
        
        prompt = f"""Please create {num_cards} educational flashcards from the following content.
        Each flashcard should have a clear question and a comprehensive answer.
        
        Vary the types of questions:
        - Definition questions (What is...?)
        - Conceptual questions (How does...work?)
        - Application questions (When would you use...?)
        - Comparison questions (What's the difference between...?)
        
        Format your response as a JSON array of objects with this structure:
        [
            {{
                "question": "Your question here?",
                "answer": "Your detailed answer here",
                "difficulty": "easy/medium/hard",
                "category": "relevant topic/category"
            }}
        ]
        
        Content:
        {content}"""
        
        messages = [
            {
                "role": "user",
                "content": prompt
            }
        ]
        
        response_text, metadata = self._make_api_call(messages, max_tokens=4000)
        
        try:
            # Extract JSON from response
            start_idx = response_text.find('[')
            end_idx = response_text.rfind(']') + 1
            
            if start_idx != -1 and end_idx != -1:
                json_text = response_text[start_idx:end_idx]
                flashcards = json.loads(json_text)
                
                # Validate and clean flashcards
                cleaned_flashcards = []
                for card in flashcards:
                    if isinstance(card, dict) and 'question' in card and 'answer' in card:
                        cleaned_card = {
                            'question': card.get('question', '').strip(),
                            'answer': card.get('answer', '').strip(),
                            'difficulty': card.get('difficulty', 'medium').lower(),
                            'category': card.get('category', '').strip()
                        }
                        
                        # Ensure difficulty is valid
                        if cleaned_card['difficulty'] not in ['easy', 'medium', 'hard']:
                            cleaned_card['difficulty'] = 'medium'
                        
                        cleaned_flashcards.append(cleaned_card)
                
                return cleaned_flashcards, metadata
            else:
                logger.error("Could not find JSON in Claude response")
                return [], metadata
                
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse flashcard JSON: {str(e)}")
            return [], metadata
    
    def extract_key_concepts(self, content: str) -> Tuple[List[str], Dict]:
        """Extract key concepts and terms from content"""
        
        prompt = """Please identify and extract the key concepts, terms, and topics from the following content.
        Return them as a simple list of concepts, one per line.
        Focus on:
        - Important terminology
        - Main concepts
        - Key theories or principles
        - Names of important people, places, or things
        
        Content:
        """
        
        messages = [
            {
                "role": "user",
                "content": f"{prompt}\n{content}"
            }
        ]
        
        response_text, metadata = self._make_api_call(messages)
        
        # Parse concepts from response
        concepts = [line.strip() for line in response_text.split('\n') if line.strip()]
        concepts = [concept.strip('- •*') for concept in concepts]  # Remove bullet points
        
        return concepts, metadata


class FileProcessingService:
    """Service for processing uploaded files and extracting text content"""
    
    @staticmethod
    def extract_text_from_pdf(file_obj) -> str:
        """Extract text content from PDF file"""
        try:
            pdf_reader = PyPDF2.PdfReader(file_obj)
            text_content = ""
            
            for page in pdf_reader.pages:
                text_content += page.extract_text() + "\n"
            
            return text_content.strip()
            
        except Exception as e:
            logger.error(f"Failed to extract text from PDF: {str(e)}")
            raise
    
    @staticmethod
    def extract_text_from_image(file_obj) -> str:
        """Extract text from image using OCR (placeholder - would need OCR library)"""
        # For now, return empty string as OCR would require additional libraries
        # In production, you'd want to use libraries like pytesseract or cloud OCR services
        logger.info("Image text extraction not implemented yet")
        return ""
    
    @staticmethod
    def get_file_content(file_obj, content_type: str) -> str:
        """Get text content from uploaded file based on type"""
        
        if content_type == 'pdf':
            return FileProcessingService.extract_text_from_pdf(file_obj)
        elif content_type == 'image':
            return FileProcessingService.extract_text_from_image(file_obj)
        elif content_type == 'text':
            # For text files, read directly
            try:
                content = file_obj.read()
                if isinstance(content, bytes):
                    content = content.decode('utf-8')
                return content
            except Exception as e:
                logger.error(f"Failed to read text file: {str(e)}")
                raise
        else:
            return ""


class ContentProcessor:
    """Main service class for processing note content with AI"""
    
    def __init__(self):
        self.claude_service = ClaudeAPIService()
        self.file_service = FileProcessingService()
    
    def process_note_content(self, note, summary_type='brief', generate_flashcards=True, num_flashcards=10):
        """Process a note's content to generate summaries and flashcards"""
        from .models import Summary, Flashcard, AIProcessingLog
        
        # Get text content
        if note.file and note.content_type != 'text':
            try:
                # Create processing log
                log = AIProcessingLog.objects.create(
                    note=note,
                    process_type='text_extraction',
                    status='processing'
                )
                
                note.file.seek(0)  # Reset file pointer
                extracted_text = self.file_service.get_file_content(note.file, note.content_type)
                note.text_content = extracted_text
                note.save()
                
                # Update log
                log.status = 'completed'
                log.completed_at = time.time()
                log.save()
                
            except Exception as e:
                log.status = 'failed'
                log.error_message = str(e)
                log.save()
                raise
        
        content = note.text_content
        if not content.strip():
            raise ValueError("No content available to process")
        
        results = {}
        
        # Generate summary
        try:
            summary_log = AIProcessingLog.objects.create(
                note=note,
                process_type='summary',
                status='processing'
            )
            
            summary_text, key_points, metadata = self.claude_service.generate_summary(content, summary_type)
            
            # Create Summary object
            summary = Summary.objects.create(
                note=note,
                summary_type=summary_type,
                content=summary_text,
                key_points=key_points,
                processing_time=metadata['processing_time'],
                ai_model_used=metadata['model_used'],
                confidence_score=0.85  # Placeholder confidence score
            )
            
            note.is_summarized = True
            note.save()
            
            # Update log
            summary_log.status = 'completed'
            summary_log.completed_at = time.time()
            summary_log.processing_time = metadata['processing_time']
            summary_log.tokens_used = metadata['tokens_used']
            summary_log.result_data = {'summary_id': summary.id}
            summary_log.save()
            
            results['summary'] = summary
            
        except Exception as e:
            summary_log.status = 'failed'
            summary_log.error_message = str(e)
            summary_log.save()
            logger.error(f"Summary generation failed for note {note.id}: {str(e)}")
        
        # Generate flashcards
        if generate_flashcards:
            try:
                flashcard_log = AIProcessingLog.objects.create(
                    note=note,
                    process_type='flashcards',
                    status='processing'
                )
                
                flashcard_data, metadata = self.claude_service.generate_flashcards(content, num_flashcards)
                
                # Create Flashcard objects
                flashcards = []
                for card_data in flashcard_data:
                    flashcard = Flashcard.objects.create(
                        note=note,
                        question=card_data['question'],
                        answer=card_data['answer'],
                        difficulty=card_data['difficulty'],
                        category=card_data['category'],
                        confidence_score=0.80  # Placeholder confidence
                    )
                    flashcards.append(flashcard)
                
                note.has_flashcards = True
                note.save()
                
                # Update log
                flashcard_log.status = 'completed'
                flashcard_log.completed_at = time.time()
                flashcard_log.processing_time = metadata['processing_time']
                flashcard_log.tokens_used = metadata['tokens_used']
                flashcard_log.result_data = {'flashcard_count': len(flashcards)}
                flashcard_log.save()
                
                results['flashcards'] = flashcards
                
            except Exception as e:
                flashcard_log.status = 'failed'
                flashcard_log.error_message = str(e)
                flashcard_log.save()
                logger.error(f"Flashcard generation failed for note {note.id}: {str(e)}")
        
        # Update note status
        note.status = 'processed'
        note.save()
        
        return results