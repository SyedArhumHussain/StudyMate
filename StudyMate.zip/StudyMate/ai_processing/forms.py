from django import forms
from .models import Flashcard, StudySession
from dashboard.models import StudyGoal


class FlashcardEditForm(forms.ModelForm):
    """Form for editing flashcards"""
    
    class Meta:
        model = Flashcard
        fields = ['question', 'answer', 'difficulty', 'category']
        widgets = {
            'question': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Enter the question'
            }),
            'answer': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Enter the answer'
            }),
            'difficulty': forms.Select(attrs={
                'class': 'form-control'
            }),
            'category': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Category or topic (optional)'
            })
        }


class StudySessionConfigForm(forms.Form):
    """Form for configuring study sessions"""
    
    SESSION_TYPE_CHOICES = [
        ('mixed', 'Mixed Review'),
        ('new', 'New Cards Only'),
        ('review', 'Review Cards'),
        ('difficult', 'Difficult Cards'),
    ]
    
    session_type = forms.ChoiceField(
        choices=SESSION_TYPE_CHOICES,
        initial='mixed',
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    card_count = forms.IntegerField(
        min_value=5,
        max_value=50,
        initial=10,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Number of cards'
        })
    )
    
    subject = forms.ModelChoiceField(
        queryset=None,
        required=False,
        empty_label="All Subjects",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            from notes.models import Subject
            self.fields['subject'].queryset = Subject.objects.filter(created_by=user)


class StudyGoalForm(forms.ModelForm):
    """Form for creating study goals"""
    
    class Meta:
        model = StudyGoal
        fields = ['goal_type', 'title', 'description', 'target_value', 'end_date', 'subject']
        widgets = {
            'goal_type': forms.Select(attrs={'class': 'form-control'}),
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Goal title'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'Goal description (optional)'
            }),
            'target_value': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Target value'
            }),
            'end_date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'subject': forms.Select(attrs={'class': 'form-control'})
        }
    
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            from notes.models import Subject
            self.fields['subject'].queryset = Subject.objects.filter(created_by=user)
        
        # Make subject optional
        self.fields['subject'].required = False
        self.fields['subject'].empty_label = "All Subjects"


class FlashcardSearchForm(forms.Form):
    """Form for searching flashcards"""
    
    search = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search flashcards...'
        })
    )
    
    subject = forms.ModelChoiceField(
        queryset=None,
        required=False,
        empty_label="All Subjects",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    difficulty = forms.ChoiceField(
        choices=[('', 'All Difficulties')] + Flashcard.DIFFICULTY_CHOICES,
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    
    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            from notes.models import Subject
            self.fields['subject'].queryset = Subject.objects.filter(created_by=user)