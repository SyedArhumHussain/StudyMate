from django.db import models
from core.models import User
from notes.models import Note


class Summary(models.Model):
    SUMMARY_TYPE_CHOICES = [
        ('brief', 'Brief Summary'),
        ('detailed', 'Detailed Summary'),
        ('key_points', 'Key Points'),
        ('abstract', 'Abstract'),
    ]
    
    note = models.OneToOneField(Note, on_delete=models.CASCADE, related_name='summary')
    summary_type = models.CharField(max_length=12, choices=SUMMARY_TYPE_CHOICES, default='brief')
    content = models.TextField()
    key_points = models.JSONField(default=list, help_text="List of key points extracted from content")
    
    # AI Processing metadata
    processing_time = models.FloatField(help_text="Time taken to process in seconds")
    ai_model_used = models.CharField(max_length=100, default='claude-3')
    confidence_score = models.FloatField(null=True, blank=True, help_text="AI confidence in summary quality")
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Summary of {self.note.title}"
    
    @property
    def word_count(self):
        return len(self.content.split())


class Flashcard(models.Model):
    DIFFICULTY_CHOICES = [
        ('easy', 'Easy'),
        ('medium', 'Medium'),
        ('hard', 'Hard'),
    ]
    
    note = models.ForeignKey(Note, on_delete=models.CASCADE, related_name='flashcards')
    question = models.TextField()
    answer = models.TextField()
    difficulty = models.CharField(max_length=6, choices=DIFFICULTY_CHOICES, default='medium')
    category = models.CharField(max_length=100, blank=True, help_text="Topic or category of the flashcard")
    
    # Study tracking
    times_reviewed = models.PositiveIntegerField(default=0)
    times_correct = models.PositiveIntegerField(default=0)
    last_reviewed = models.DateTimeField(null=True, blank=True)
    
    # AI metadata
    ai_generated = models.BooleanField(default=True)
    confidence_score = models.FloatField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['note', 'difficulty']),
            models.Index(fields=['last_reviewed']),
        ]
    
    def __str__(self):
        return f"Flashcard: {self.question[:50]}..."
    
    @property
    def success_rate(self):
        if self.times_reviewed == 0:
            return 0
        return (self.times_correct / self.times_reviewed) * 100


class StudySession(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='study_sessions')
    flashcards = models.ManyToManyField(Flashcard, through='StudySessionFlashcard', related_name='study_sessions')
    
    session_name = models.CharField(max_length=200)
    total_cards = models.PositiveIntegerField()
    correct_answers = models.PositiveIntegerField(default=0)
    completed = models.BooleanField(default=False)
    
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    duration_seconds = models.PositiveIntegerField(null=True, blank=True)
    
    class Meta:
        ordering = ['-started_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.session_name}"
    
    @property
    def score_percentage(self):
        if self.total_cards == 0:
            return 0
        return (self.correct_answers / self.total_cards) * 100


class StudySessionFlashcard(models.Model):
    study_session = models.ForeignKey(StudySession, on_delete=models.CASCADE)
    flashcard = models.ForeignKey(Flashcard, on_delete=models.CASCADE)
    
    answered_correctly = models.BooleanField(null=True)
    response_time_seconds = models.PositiveIntegerField(null=True)
    answered_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('study_session', 'flashcard')
    
    def __str__(self):
        return f"{self.study_session.session_name} - {self.flashcard.question[:30]}..."


class AIProcessingLog(models.Model):
    PROCESS_TYPE_CHOICES = [
        ('summary', 'Summary Generation'),
        ('flashcards', 'Flashcard Generation'),
        ('key_extraction', 'Key Points Extraction'),
        ('text_extraction', 'Text Extraction from File'),
    ]
    
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('failed', 'Failed'),
        ('retrying', 'Retrying'),
    ]
    
    note = models.ForeignKey(Note, on_delete=models.CASCADE, related_name='processing_logs')
    process_type = models.CharField(max_length=15, choices=PROCESS_TYPE_CHOICES)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    
    # Processing details
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    processing_time = models.FloatField(null=True, blank=True)
    
    # Results and errors
    result_data = models.JSONField(null=True, blank=True, help_text="Processing results or error details")
    error_message = models.TextField(blank=True)
    retry_count = models.PositiveIntegerField(default=0)
    
    # AI service details
    ai_model = models.CharField(max_length=100, default='claude-3')
    tokens_used = models.PositiveIntegerField(null=True, blank=True)
    
    class Meta:
        ordering = ['-started_at']
        indexes = [
            models.Index(fields=['note', 'process_type']),
            models.Index(fields=['status']),
        ]
    
    def __str__(self):
        return f"{self.note.title} - {self.get_process_type_display()} - {self.status}"
