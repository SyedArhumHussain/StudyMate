from celery import shared_task
from django.utils import timezone
from .services import ContentProcessor
from .models import AIProcessingLog
import logging

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def process_note_content_async(self, note_id, summary_type='brief', generate_flashcards=True, num_flashcards=10):
    """Asynchronously process note content to generate summaries and flashcards"""
    
    try:
        from notes.models import Note
        
        note = Note.objects.get(id=note_id)
        note.status = 'processing'
        note.save()
        
        # Initialize processor
        processor = ContentProcessor()
        
        # Process the content
        results = processor.process_note_content(
            note=note,
            summary_type=summary_type,
            generate_flashcards=generate_flashcards,
            num_flashcards=num_flashcards
        )
        
        # Update user statistics
        update_user_statistics.delay(note.uploaded_by.id)
        
        # Log user activity
        from dashboard.models import UserActivity
        UserActivity.objects.create(
            user=note.uploaded_by,
            activity_type='summary_generated' if 'summary' in results else 'note_processed',
            description=f"Processed note: {note.title}",
            note=note,
            subject=note.subject,
            metadata={
                'has_summary': 'summary' in results,
                'flashcard_count': len(results.get('flashcards', []))
            }
        )
        
        return {
            'success': True,
            'note_id': note_id,
            'has_summary': 'summary' in results,
            'flashcard_count': len(results.get('flashcards', []))
        }
        
    except Exception as exc:
        logger.error(f"Task failed for note {note_id}: {str(exc)}")
        
        # Update note status
        try:
            note = Note.objects.get(id=note_id)
            note.status = 'failed'
            note.save()
        except:
            pass
        
        # Retry logic
        if self.request.retries < self.max_retries:
            logger.info(f"Retrying task for note {note_id}. Attempt {self.request.retries + 1}")
            raise self.retry(countdown=60 * (2 ** self.request.retries))  # Exponential backoff
        
        return {
            'success': False,
            'note_id': note_id,
            'error': str(exc)
        }


@shared_task
def update_user_statistics(user_id):
    """Update user statistics after processing"""
    
    try:
        from core.models import User
        from dashboard.models import UserStudyStatistics
        from notes.models import Note
        from ai_processing.models import Summary, Flashcard
        
        user = User.objects.get(id=user_id)
        stats, created = UserStudyStatistics.objects.get_or_create(user=user)
        
        # Update note statistics
        user_notes = Note.objects.filter(uploaded_by=user)
        stats.total_notes_uploaded = user_notes.count()
        stats.total_notes_processed = user_notes.filter(status='processed').count()
        
        # Update summary statistics
        stats.total_summaries_generated = Summary.objects.filter(note__uploaded_by=user).count()
        
        # Update flashcard statistics
        stats.total_flashcards_created = Flashcard.objects.filter(note__uploaded_by=user).count()
        
        stats.save()
        
        logger.info(f"Updated statistics for user {user_id}")
        
    except Exception as e:
        logger.error(f"Failed to update statistics for user {user_id}: {str(e)}")


@shared_task
def cleanup_old_processing_logs():
    """Clean up old processing logs (older than 30 days)"""
    
    try:
        from datetime import timedelta
        cutoff_date = timezone.now() - timedelta(days=30)
        
        old_logs = AIProcessingLog.objects.filter(
            started_at__lt=cutoff_date,
            status__in=['completed', 'failed']
        )
        
        count = old_logs.count()
        old_logs.delete()
        
        logger.info(f"Cleaned up {count} old processing logs")
        return f"Cleaned up {count} logs"
        
    except Exception as e:
        logger.error(f"Failed to cleanup logs: {str(e)}")
        return f"Error: {str(e)}"


@shared_task
def regenerate_flashcards(note_id, num_flashcards=10):
    """Regenerate flashcards for a specific note"""
    
    try:
        from notes.models import Note
        from ai_processing.models import Flashcard
        
        note = Note.objects.get(id=note_id)
        
        # Delete existing flashcards
        Flashcard.objects.filter(note=note).delete()
        
        # Generate new flashcards
        processor = ContentProcessor()
        claude_service = processor.claude_service
        
        if not note.text_content:
            raise ValueError("No text content available for flashcard generation")
        
        flashcard_data, metadata = claude_service.generate_flashcards(note.text_content, num_flashcards)
        
        # Create new flashcards
        flashcards = []
        for card_data in flashcard_data:
            flashcard = Flashcard.objects.create(
                note=note,
                question=card_data['question'],
                answer=card_data['answer'],
                difficulty=card_data['difficulty'],
                category=card_data['category'],
                confidence_score=0.80
            )
            flashcards.append(flashcard)
        
        note.has_flashcards = True
        note.save()
        
        # Log activity
        from dashboard.models import UserActivity
        UserActivity.objects.create(
            user=note.uploaded_by,
            activity_type='flashcard_created',
            description=f"Regenerated {len(flashcards)} flashcards for: {note.title}",
            note=note,
            subject=note.subject,
            metadata={'flashcard_count': len(flashcards)}
        )
        
        return {
            'success': True,
            'note_id': note_id,
            'flashcard_count': len(flashcards)
        }
        
    except Exception as e:
        logger.error(f"Failed to regenerate flashcards for note {note_id}: {str(e)}")
        return {
            'success': False,
            'note_id': note_id,
            'error': str(e)
        }


@shared_task
def batch_process_notes(note_ids):
    """Process multiple notes in batch"""
    
    results = []
    
    for note_id in note_ids:
        try:
            result = process_note_content_async.delay(note_id)
            results.append({
                'note_id': note_id,
                'task_id': result.id,
                'status': 'queued'
            })
        except Exception as e:
            results.append({
                'note_id': note_id,
                'status': 'error',
                'error': str(e)
            })
    
    return results