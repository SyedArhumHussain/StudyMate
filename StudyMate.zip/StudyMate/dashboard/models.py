from django.db import models
from core.models import User, Subject
from notes.models import Note


class UserActivity(models.Model):
    ACTIVITY_TYPE_CHOICES = [
        ('note_upload', 'Note Upload'),
        ('note_view', 'Note View'),
        ('summary_generated', 'Summary Generated'),
        ('flashcard_created', 'Flashcard Created'),
        ('study_session', 'Study Session'),
        ('login', 'Login'),
        ('logout', 'Logout'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='activities')
    activity_type = models.CharField(max_length=20, choices=ACTIVITY_TYPE_CHOICES)
    description = models.CharField(max_length=255)
    
    # Optional related objects
    note = models.ForeignKey(Note, on_delete=models.CASCADE, null=True, blank=True)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, null=True, blank=True)
    
    # Additional data
    metadata = models.JSONField(default=dict, help_text="Additional activity data")
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['user', 'activity_type']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"{self.user.username} - {self.get_activity_type_display()}"


class UserStudyStatistics(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='study_statistics')
    
    # Notes statistics
    total_notes_uploaded = models.PositiveIntegerField(default=0)
    total_notes_processed = models.PositiveIntegerField(default=0)
    
    # Summary statistics
    total_summaries_generated = models.PositiveIntegerField(default=0)
    
    # Flashcard statistics
    total_flashcards_created = models.PositiveIntegerField(default=0)
    total_flashcards_studied = models.PositiveIntegerField(default=0)
    
    # Study session statistics
    total_study_sessions = models.PositiveIntegerField(default=0)
    total_study_time_minutes = models.PositiveIntegerField(default=0)
    average_session_score = models.FloatField(default=0.0)
    
    # Streak tracking
    current_study_streak = models.PositiveIntegerField(default=0)
    longest_study_streak = models.PositiveIntegerField(default=0)
    last_study_date = models.DateField(null=True, blank=True)
    
    # Performance metrics
    overall_accuracy = models.FloatField(default=0.0, help_text="Percentage of correct answers")
    
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Statistics for {self.user.username}"
    
    @property
    def notes_processing_rate(self):
        if self.total_notes_uploaded == 0:
            return 0
        return (self.total_notes_processed / self.total_notes_uploaded) * 100


class SubjectProgress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='subject_progress')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='user_progress')
    
    # Progress metrics
    notes_count = models.PositiveIntegerField(default=0)
    summaries_count = models.PositiveIntegerField(default=0)
    flashcards_count = models.PositiveIntegerField(default=0)
    
    # Study metrics
    study_sessions_count = models.PositiveIntegerField(default=0)
    total_study_time_minutes = models.PositiveIntegerField(default=0)
    average_score = models.FloatField(default=0.0)
    
    # Last activity
    last_studied = models.DateTimeField(null=True, blank=True)
    last_note_uploaded = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ('user', 'subject')
        ordering = ['-last_studied', 'subject__name']
    
    def __str__(self):
        return f"{self.user.username} - {self.subject.name}"


class DashboardWidget(models.Model):
    WIDGET_TYPE_CHOICES = [
        ('recent_notes', 'Recent Notes'),
        ('study_progress', 'Study Progress'),
        ('flashcard_review', 'Flashcard Review'),
        ('subject_overview', 'Subject Overview'),
        ('activity_feed', 'Activity Feed'),
        ('performance_chart', 'Performance Chart'),
        ('upcoming_reviews', 'Upcoming Reviews'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='dashboard_widgets')
    widget_type = models.CharField(max_length=20, choices=WIDGET_TYPE_CHOICES)
    position = models.PositiveIntegerField(default=0, help_text="Display order on dashboard")
    is_visible = models.BooleanField(default=True)
    
    # Widget configuration
    configuration = models.JSONField(default=dict, help_text="Widget-specific settings and preferences")
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['position']
        unique_together = ('user', 'widget_type')
    
    def __str__(self):
        return f"{self.user.username} - {self.get_widget_type_display()}"


class StudyGoal(models.Model):
    GOAL_TYPE_CHOICES = [
        ('daily_study', 'Daily Study Time'),
        ('weekly_notes', 'Weekly Notes Upload'),
        ('flashcard_review', 'Daily Flashcard Review'),
        ('subject_focus', 'Subject-specific Goal'),
        ('streak_maintenance', 'Study Streak'),
    ]
    
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('completed', 'Completed'),
        ('paused', 'Paused'),
        ('expired', 'Expired'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='study_goals')
    goal_type = models.CharField(max_length=20, choices=GOAL_TYPE_CHOICES)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    
    # Goal parameters
    target_value = models.PositiveIntegerField(help_text="Target number (minutes, notes count, etc.)")
    current_value = models.PositiveIntegerField(default=0)
    
    # Timeline
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    
    # Optional subject association
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.title}"
    
    @property
    def progress_percentage(self):
        if self.target_value == 0:
            return 0
        return min((self.current_value / self.target_value) * 100, 100)
    
    @property
    def is_achieved(self):
        return self.current_value >= self.target_value
