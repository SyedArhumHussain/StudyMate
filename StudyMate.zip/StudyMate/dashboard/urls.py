from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    # Main dashboard
    path('', views.dashboard, name='dashboard'),
    path('analytics/', views.analytics, name='analytics'),
    
    # Study sessions
    path('study-session/start/', views.study_session_start, name='study_session_start'),
    path('study-session/<int:session_id>/', views.study_session_detail, name='study_session_detail'),
    
    # Goals and widgets
    path('goals/', views.goals, name='goals'),
    path('widgets/', views.widget_config, name='widget_config'),
    
    # API endpoints
    path('api/stats/', views.api_dashboard_stats, name='api_dashboard_stats'),
    path('api/subject-progress/', views.api_subject_progress, name='api_subject_progress'),
    path('api/recent-activity/', views.api_recent_activity, name='api_recent_activity'),
]