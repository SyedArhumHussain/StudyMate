from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db.models import Count, Q, Avg
from django.utils import timezone
from datetime import datetime, timedelta
from .models import (
    UserStudyStatistics, UserActivity, SubjectProgress, 
    DashboardWidget, StudyGoal
)
from notes.models import Note, Subject
from ai_processing.models import Flashcard, StudySession, Summary
import json


@login_required
def dashboard(request):
    """Main dashboard view"""
    user = request.user
    
    # Get or create user statistics
    stats, created = UserStudyStatistics.objects.get_or_create(user=user)
    
    # Get recent notes
    recent_notes = Note.objects.filter(uploaded_by=user).order_by('-created_at')[:5]
    
    # Get subject progress
    subject_progress = SubjectProgress.objects.filter(user=user).select_related('subject')[:4]
    
    # Get recent activities
    recent_activities = UserActivity.objects.filter(user=user).order_by('-created_at')[:10]
    
    # Get active study goals
    active_goals = StudyGoal.objects.filter(user=user, status='active').order_by('-created_at')[:3]
    
    # Calculate daily study streak
    today = timezone.now().date()
    study_sessions_today = StudySession.objects.filter(
        user=user,
        started_at__date=today
    ).count()
    
    # Get flashcards due for review (simplified logic)
    flashcards_due = Flashcard.objects.filter(
        note__uploaded_by=user,
        times_reviewed__lt=3  # Flashcards reviewed less than 3 times
    ).count()
    
    context = {
        'stats': stats,
        'recent_notes': recent_notes,
        'subject_progress': subject_progress,
        'recent_activities': recent_activities,
        'active_goals': active_goals,
        'study_sessions_today': study_sessions_today,
        'flashcards_due': flashcards_due,
        'total_subjects': Subject.objects.filter(created_by=user).count(),
    }
    
    return render(request, 'dashboard/dashboard.html', context)


@login_required
def analytics(request):
    """Analytics and detailed statistics view"""
    user = request.user
    
    # Time range filter
    days = int(request.GET.get('days', 30))
    start_date = timezone.now() - timedelta(days=days)
    
    # Study session analytics
    study_sessions = StudySession.objects.filter(
        user=user,
        started_at__gte=start_date
    ).order_by('started_at')
    
    # Note upload analytics
    notes_uploaded = Note.objects.filter(
        uploaded_by=user,
        created_at__gte=start_date
    ).values('created_at__date').annotate(count=Count('id')).order_by('created_at__date')
    
    # Subject performance
    subject_performance = SubjectProgress.objects.filter(
        user=user
    ).select_related('subject').order_by('-average_score')
    
    # Daily activity data
    daily_activities = UserActivity.objects.filter(
        user=user,
        created_at__gte=start_date
    ).extra(
        select={'day': 'date(created_at)'}
    ).values('day').annotate(count=Count('id')).order_by('day')
    
    context = {
        'days': days,
        'study_sessions': study_sessions,
        'notes_uploaded': list(notes_uploaded),
        'subject_performance': subject_performance,
        'daily_activities': list(daily_activities),
    }
    
    return render(request, 'dashboard/analytics.html', context)


@login_required
def study_session_start(request):
    """Start a new study session"""
    if request.method == 'POST':
        session_type = request.POST.get('session_type', 'mixed')
        subject_id = request.POST.get('subject_id')
        card_count = int(request.POST.get('card_count', 10))
        
        # Get flashcards based on criteria
        flashcards = Flashcard.objects.filter(note__uploaded_by=request.user)
        
        if subject_id:
            flashcards = flashcards.filter(note__subject_id=subject_id)
        
        if session_type == 'review':
            # Prioritize cards that need review
            flashcards = flashcards.filter(times_reviewed__gt=0).order_by('last_reviewed')
        elif session_type == 'new':
            # New cards only
            flashcards = flashcards.filter(times_reviewed=0).order_by('created_at')
        else:
            # Mixed - all cards
            flashcards = flashcards.order_by('?')  # Random order
        
        flashcards = flashcards[:card_count]
        
        if not flashcards:
            return JsonResponse({
                'success': False,
                'error': 'No flashcards available for this session type'
            })
        
        # Create study session
        session = StudySession.objects.create(
            user=request.user,
            session_name=f"{session_type.title()} Study Session",
            total_cards=len(flashcards)
        )
        
        session.flashcards.set(flashcards)
        
        return JsonResponse({
            'success': True,
            'session_id': session.id,
            'redirect_url': f'/study-session/{session.id}/'
        })
    
    # GET request - show session setup form
    subjects = Subject.objects.filter(created_by=request.user)
    context = {'subjects': subjects}
    return render(request, 'dashboard/study_session_start.html', context)


@login_required
def study_session_detail(request, session_id):
    """Study session interface"""
    session = get_object_or_404(StudySession, id=session_id, user=request.user)
    
    # Get session flashcards in order
    session_flashcards = session.flashcards.all()
    
    context = {
        'session': session,
        'flashcards': session_flashcards,
        'total_cards': session.total_cards,
    }
    
    return render(request, 'dashboard/study_session.html', context)


@login_required
def widget_config(request):
    """Configure dashboard widgets"""
    if request.method == 'POST':
        data = json.loads(request.body)
        widget_configs = data.get('widgets', [])
        
        # Clear existing widgets
        DashboardWidget.objects.filter(user=request.user).delete()
        
        # Create new widget configurations
        for config in widget_configs:
            DashboardWidget.objects.create(
                user=request.user,
                widget_type=config['type'],
                position=config['position'],
                is_visible=config.get('visible', True),
                configuration=config.get('config', {})
            )
        
        return JsonResponse({'success': True})
    
    # GET request - show widget configuration page
    widgets = DashboardWidget.objects.filter(user=request.user).order_by('position')
    return render(request, 'dashboard/widget_config.html', {'widgets': widgets})


@login_required
def goals(request):
    """Study goals management"""
    if request.method == 'POST':
        # Create new goal
        goal_type = request.POST.get('goal_type')
        title = request.POST.get('title')
        description = request.POST.get('description', '')
        target_value = int(request.POST.get('target_value'))
        end_date = request.POST.get('end_date')
        subject_id = request.POST.get('subject_id')
        
        goal = StudyGoal.objects.create(
            user=request.user,
            goal_type=goal_type,
            title=title,
            description=description,
            target_value=target_value,
            start_date=timezone.now().date(),
            end_date=datetime.strptime(end_date, '%Y-%m-%d').date(),
            subject_id=subject_id if subject_id else None
        )
        
        return JsonResponse({
            'success': True,
            'goal_id': goal.id,
            'message': 'Goal created successfully!'
        })
    
    # GET request
    goals = StudyGoal.objects.filter(user=request.user).order_by('-created_at')
    subjects = Subject.objects.filter(created_by=request.user)
    
    context = {
        'goals': goals,
        'subjects': subjects,
    }
    
    return render(request, 'dashboard/goals.html', context)


@login_required
def api_dashboard_stats(request):
    """API endpoint for dashboard statistics"""
    user = request.user
    stats, created = UserStudyStatistics.objects.get_or_create(user=user)
    
    # Recent activity count by type
    activity_counts = UserActivity.objects.filter(
        user=user,
        created_at__gte=timezone.now() - timedelta(days=7)
    ).values('activity_type').annotate(count=Count('id'))
    
    return JsonResponse({
        'total_notes': stats.total_notes_uploaded,
        'total_summaries': stats.total_summaries_generated,
        'total_flashcards': stats.total_flashcards_created,
        'total_sessions': stats.total_study_sessions,
        'current_streak': stats.current_study_streak,
        'average_score': stats.average_session_score,
        'recent_activity': list(activity_counts)
    })


@login_required
def api_subject_progress(request):
    """API endpoint for subject progress data"""
    progress = SubjectProgress.objects.filter(user=request.user).select_related('subject')
    
    data = []
    for prog in progress:
        data.append({
            'subject_name': prog.subject.name,
            'subject_color': prog.subject.color,
            'notes_count': prog.notes_count,
            'flashcards_count': prog.flashcards_count,
            'average_score': prog.average_score,
            'total_study_time': prog.total_study_time_minutes,
            'last_studied': prog.last_studied.isoformat() if prog.last_studied else None
        })
    
    return JsonResponse({'subjects': data})


@login_required
def api_recent_activity(request):
    """API endpoint for recent user activity"""
    activities = UserActivity.objects.filter(
        user=request.user
    ).order_by('-created_at')[:20]
    
    data = []
    for activity in activities:
        data.append({
            'type': activity.activity_type,
            'description': activity.description,
            'created_at': activity.created_at.isoformat(),
            'note_title': activity.note.title if activity.note else None,
            'subject_name': activity.subject.name if activity.subject else None
        })
    
    return JsonResponse({'activities': data})
