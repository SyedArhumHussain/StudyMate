#!/usr/bin/env python
"""
Debug Claude API responses
"""
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'StudyMate.settings')
django.setup()

from ai_processing.services import ClaudeAPIService

def debug_claude_response():
    print("Debugging Claude API responses...")
    
    try:
        claude_service = ClaudeAPIService()
        
        test_content = """
        Python Basics
        
        Python is a programming language. Variables store data. Functions perform tasks.
        
        Example: x = 5, def hello(): print("Hi")
        """
        
        print("Testing flashcard generation...")
        
        # Make the API call directly to see raw response
        messages = [
            {
                "role": "user",
                "content": f"""Please create 2 educational flashcards from the following content.
        Each flashcard should have a clear question and a comprehensive answer.
        
        Format your response as a JSON array of objects with this structure:
        [
            {{
                "question": "Your question here?",
                "answer": "Your detailed answer here",
                "difficulty": "easy/medium/hard",
                "category": "relevant topic/category"
            }}
        ]
        
        Content:
        {test_content}"""
            }
        ]
        
        response_text, metadata = claude_service._make_api_call(messages, max_tokens=1000)
        
        print("=== RAW CLAUDE RESPONSE ===")
        print(response_text)
        print("=" * 50)
        
        # Now try the parsing
        print("\nTrying to parse JSON...")
        import json
        
        start_idx = response_text.find('[')
        end_idx = response_text.rfind(']') + 1
        
        if start_idx != -1 and end_idx != -1:
            json_text = response_text[start_idx:end_idx]
            print(f"Extracted JSON text: {json_text}")
            
            try:
                flashcards = json.loads(json_text)
                print(f"Successfully parsed {len(flashcards)} flashcards!")
                for i, card in enumerate(flashcards, 1):
                    print(f"Card {i}: {card}")
            except json.JSONDecodeError as e:
                print(f"JSON decode error: {e}")
        else:
            print("No JSON array found in response")
        
        return True
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return False

if __name__ == "__main__":
    debug_claude_response()