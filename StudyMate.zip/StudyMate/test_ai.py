#!/usr/bin/env python
"""
Quick test script to verify Claude API integration
"""
import os
import django
from django.conf import settings

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'StudyMate.settings')
django.setup()

from ai_processing.services import ClaudeAPIService

def test_claude_api():
    print("Testing Claude API integration...")
    
    try:
        # Initialize the Claude service
        claude_service = ClaudeAPIService()
        
        # Test content
        test_content = """
        Machine Learning Basics
        
        Machine learning is a subset of artificial intelligence that focuses on creating systems that can learn and improve from experience without being explicitly programmed.
        
        Types of Machine Learning:
        1. Supervised Learning - Learning with labeled examples
        2. Unsupervised Learning - Finding patterns in unlabeled data  
        3. Reinforcement Learning - Learning through trial and error
        
        Key concepts include algorithms, training data, features, and model evaluation.
        """
        
        print("Generating summary...")
        summary, key_points, metadata = claude_service.generate_summary(test_content, 'brief')
        
        print("\n=== SUMMARY ===")
        print(summary)
        print("\n=== KEY POINTS ===")
        for i, point in enumerate(key_points, 1):
            print(f"{i}. {point}")
        
        print(f"\n=== METADATA ===")
        print(f"Processing time: {metadata['processing_time']:.2f} seconds")
        print(f"Tokens used: {metadata['tokens_used']}")
        print(f"Model: {metadata['model_used']}")
        
        print("\nGenerating flashcards...")
        flashcards, fc_metadata = claude_service.generate_flashcards(test_content, 3)
        
        print(f"\n=== FLASHCARDS ({len(flashcards)} generated) ===")
        for i, card in enumerate(flashcards, 1):
            print(f"\nCard {i} ({card['difficulty']}):")
            print(f"Q: {card['question']}")
            print(f"A: {card['answer']}")
            if card['category']:
                print(f"Category: {card['category']}")
        
        print(f"\nFlashcard processing time: {fc_metadata['processing_time']:.2f} seconds")
        print(f"Flashcard tokens used: {fc_metadata['tokens_used']}")
        
        print("\nClaude API integration test SUCCESSFUL!")
        return True
        
    except Exception as e:
        print(f"\nX Claude API integration test FAILED: {str(e)}")
        return False

if __name__ == "__main__":
    test_claude_api()